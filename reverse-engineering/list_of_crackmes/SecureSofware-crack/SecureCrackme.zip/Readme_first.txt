===IMPORTANT====
For important info, read caution.txt



Thank you for purchasing SecureSoftware!

SecureSoftware keeps your data secure. 

Here are the instructions. 


1. Run the software from a console, and make sure initialisation was successful.

2. If the software asks for a key, contact key@xyz.com with your authdata to get a keybundle.

3. Use the keyinstall.exe with your keybundle to validate purchase.

4. Secure your data!!



If you see "Unauthorized modification detected", close all other application running. Then try to run the program with '-r' to reset the data directory. 
If you are seeing the message again and again, restart your pc, or possibly reset it, as your windows might be corrupted.

